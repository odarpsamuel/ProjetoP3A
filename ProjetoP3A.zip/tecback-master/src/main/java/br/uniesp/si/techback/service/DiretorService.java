package br.uniesp.si.techback.service;

import br.uniesp.si.techback.model.Diretor;
import br.uniesp.si.techback.repository.DiretorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DiretorService {

    @Autowired
    private DiretorRepository repository;

    public List<Diretor> listarTodos() {
        return repository.findAll();
    }

    public Optional<Diretor> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public Diretor salvar(Diretor diretor) {
        return repository.save(diretor);
    }

    public Diretor atualizar(Integer id, Diretor diretorAtualizado) {
        return repository.findById(id)
                .map(diretor -> {
                    diretor.setNome(diretorAtualizado.getNome());
                    diretor.setIdade(diretorAtualizado.getIdade());
                    return repository.save(diretor);
                }).orElseThrow(() -> new RuntimeException("Diretor não encontrado"));
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }
}