package br.uniesp.si.techback.controller;

import br.uniesp.si.techback.model.Diretor;
import br.uniesp.si.techback.service.DiretorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diretores")
public class DiretorController {

    @Autowired
    private DiretorService service;

    @GetMapping
    public List<Diretor> listarDiretores() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public Diretor buscarDiretor(@PathVariable Integer id) {
        return service.buscarPorId(id).orElseThrow(() -> new RuntimeException("Diretor não encontrado"));
    }

    @PostMapping
    public Diretor criarDiretor(@RequestBody Diretor diretor) {
        return service.salvar(diretor);
    }

    @PutMapping("/{id}")
    public Diretor atualizarDiretor(@PathVariable Integer id, @RequestBody Diretor diretor) {
        return service.atualizar(id, diretor);
    }

    @DeleteMapping("/{id}")
    public void deletarDiretor(@PathVariable Integer id) {
        service.deletar(id);
    }
}