package br.uniesp.si.techback.controller;

import br.uniesp.si.techback.model.Categoria;
import br.uniesp.si.techback.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService service;

    @GetMapping
    public List<Categoria> listarCategorias() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public Categoria buscarCategoria(@PathVariable Integer id) {
        return service.buscarPorId(id).orElseThrow(() -> new RuntimeException("Categoria não encontrada"));
    }

    @PostMapping
    public Categoria criarCategoria(@RequestBody Categoria categoria) {
        return service.salvar(categoria);
    }

    @PutMapping("/{id}")
    public Categoria atualizarCategoria(@PathVariable Integer id, @RequestBody Categoria categoria) {
        return service.atualizar(id, categoria);
    }

    @DeleteMapping("/{id}")
    public void deletarCategoria(@PathVariable Integer id) {
        service.deletar(id);
    }
}