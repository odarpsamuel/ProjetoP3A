package br.uniesp.si.techback.controller;

import br.uniesp.si.techback.model.EntidadeBase;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/base")
public class ControllerBase {

    private List<EntidadeBase> entidades = new ArrayList<>();

    @GetMapping
    public List<EntidadeBase> listarEntidades() {
        return entidades;
    }

    @GetMapping("/{id}")
    public EntidadeBase buscarEntidade(@PathVariable int id) {
        return entidades.stream()
                .filter(entidade -> entidade.getAno() == id)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Entidade não encontrada"));
    }

    @PostMapping
    public EntidadeBase criarEntidade(@RequestBody EntidadeBase entidadeBase) {
        entidades.add(entidadeBase);
        return entidadeBase;
    }

    @PutMapping("/{id}")
    public EntidadeBase atualizarEntidade(@PathVariable int id, @RequestBody EntidadeBase entidadeAtualizada) {
        for (int i = 0; i < entidades.size(); i++) {
            if (entidades.get(i).getAno() == id) {
                entidades.set(i, entidadeAtualizada);
                return entidadeAtualizada;
            }
        }
        throw new RuntimeException("Entidade não encontrada");
    }

    @DeleteMapping("/{id}")
    public void deletarEntidade(@PathVariable int id) {
        entidades.removeIf(entidade -> entidade.getAno() == id);
    }
}